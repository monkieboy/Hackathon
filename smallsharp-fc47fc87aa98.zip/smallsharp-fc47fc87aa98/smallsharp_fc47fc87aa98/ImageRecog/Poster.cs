﻿using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using unirest_net.http;

namespace ImageRecog
{
    public class Poster
    {
        public string GetAnswer(byte[] file)
        {
            var httpResponse = Unirest.post("https://camfind.p.mashape.com/image_requests")
                .header("X-Mashape-Key", "GMt66FGPFymshdIyw3ZzjXKNOto7p1ermPSjsnJckTtePs5UGm")
//                .field("image_request[image]", file)
                .field("image_request[image]", System.IO.File.ReadAllBytes("C:\\temp\\boo.png"))
                .field("image_request[locale]", "en_US")
                .asJson<TokenResult>();
            
            var token = httpResponse.Body.Token;

            var answer = GetGuess(token);
            return answer;
        }

        public string GetGuess(string token)
        {
            var url = "https://camfind.p.mashape.com/image_responses/" + token;
            var c = Unirest.get(url)
                .header("X-Mashape-Key", "GMt66FGPFymshdIyw3ZzjXKNOto7p1ermPSjsnJckTtePs5UGm")
                .header("Accept", "application/json")
                .asJson<TokenResponse>();

            if (c.Body.Status == "completed") return c.Body.Name;
            return string.Empty;
        }
    }

    public class TokenResult
    {
        public string Token
        {
            get;
            set;
        }
    }

    public class TokenResponse
{
    public string Status { get; set; }
    public string Name { get; set; }
    public string Reason { get; set; }
}
}
