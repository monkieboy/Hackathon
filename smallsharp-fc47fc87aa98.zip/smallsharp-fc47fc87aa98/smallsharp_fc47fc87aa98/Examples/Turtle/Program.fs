﻿open Library

do  GraphicsWindow.Title <- "Turtle Example"
    GraphicsWindow.Show()    
    pencolor red
    repeat 10 (fun () -> rt 36; repeat 5 (fun () -> fd 54; rt 72))
    
    
    
