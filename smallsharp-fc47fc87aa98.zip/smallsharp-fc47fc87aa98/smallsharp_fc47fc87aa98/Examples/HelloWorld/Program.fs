﻿open Library

TextWindow.WriteLine("Hello World")
GraphicsWindow.Title <- "Hello"
GraphicsWindow.Show()
GraphicsWindow.BrushColor <- yellow
GraphicsWindow.PenColor <- black
GraphicsWindow.PenWidth <- 5.0
GraphicsWindow.FillEllipse(50,50,200,200)
GraphicsWindow.DrawEllipse(50,50,200,200)
GraphicsWindow.DrawEllipse(90,90,120,120)
GraphicsWindow.FillRectangle(90,90,120,60)
GraphicsWindow.PenWidth <- 10.0
GraphicsWindow.DrawEllipse(90,100,10,10)
GraphicsWindow.DrawEllipse(200,100,10,10)
