﻿open Library
open FSharp.Data.HttpRequestHeaders
open FSharp.Data

let url = "https://camfind.p.mashape.com/image_requests"
let convertToByte (name:string) = [0x20; 0x20; 0x20; 0x20; 0x20; 0x20; 0x20 ] |> Array.ofList 
let file = convertToByte "sss" 

let something = 
    Http.RequestString
    ( url,
      headers = [ Accept HttpContentTypes.Json ] ) //; "X-Mashape-Key", "uSAlY9n1YlmshOF31pqHtsfM8aAop1xGtlEjsnapwODKAdDYkw"] )
      //body = BinaryUpload [ "image_request[image]", file ] ) 
      //body = FormValues [ "image_request[language]", "en"; "image_request[locale]", "en_US" ] )

let onKeyDown () =   
   match GraphicsWindow.LastKey with
   | "D1" -> GraphicsWindow.PenColor <- Colors.Red
   | "D2" -> GraphicsWindow.PenColor <- Colors.Blue
   | "D3" -> GraphicsWindow.PenColor <- Colors.LightGreen
   | "D4" -> GraphicsWindow.PenColor <- Colors.Purple 
   | "D5" -> GraphicsWindow.PenColor <- Colors.Yellow 
   | "D6" -> GraphicsWindow.PenColor <- Colors.Gold
   | "D7" -> GraphicsWindow.PenColor <- Colors.Black
   | "Up" -> GraphicsWindow.PenWidth <- GraphicsWindow.PenWidth + 1.
   | "Down" -> GraphicsWindow.PenWidth <- GraphicsWindow.PenWidth - 1.
   | "C"  -> GraphicsWindow.Clear()
   | "S" -> GraphicsWindow.Save() |> ignore
   | _    -> ()

let mutable prevX = 0.0
let mutable prevY = 0.0

let onMouseDown () =
   prevX <- GraphicsWindow.MouseX
   prevY <- GraphicsWindow.MouseY
   
let onMouseMove () =
   let x = GraphicsWindow.MouseX
   let y = GraphicsWindow.MouseY
   if Mouse.IsLeftButtonDown then
      GraphicsWindow.DrawLine(prevX, prevY, x, y)
   prevX <- x
   prevY <- y

GraphicsWindow.BackgroundColor <- Colors.White
GraphicsWindow.PenColor <- Colors.Black
GraphicsWindow.MouseDown <- Callback(onMouseDown)
GraphicsWindow.MouseMove <- Callback(onMouseMove)
GraphicsWindow.KeyDown <- Callback(onKeyDown)

let checkImage image =
    ()

let mutable countdown = 60
Timer.Interval <- 1000
Timer.Tick <- fun () -> 
    countdown <- countdown - 1
    if countdown < 0 
    then GraphicsWindow.Title <- "Game Over, Time's Up!"
    else GraphicsWindow.Title <- "Time Remaining: " + countdown.ToString()

//GraphicsWindow